The nagios command lines to check the 3HK and USCC video are as follows:


ruby nov_check_video_sites.rb /usr/local/groundwork/nagios/libexec/ruby_plug-ins/3hk_video_sites.conf
ruby nov_check_video_sites.rb /usr/local/groundwork/nagios/libexec/ruby_plug-ins/uscc_video_sites.conf

