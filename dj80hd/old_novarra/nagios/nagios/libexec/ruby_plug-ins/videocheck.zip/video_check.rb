require 'nagios_plugin'
require 'uri'
require 'aca_client'
#
# Nagios plugin to check video sites.
# A video site will be loaded, then the plugin will search for video links on 
# that site.  One of those video links will be followed and then the script will
# expect to find an rtsp link somewhere in the content.
#
class VideoCheck < NagiosPlugin

  #
  # Perform the video check
  # Parameters of the video check to be performed are supplied in config_file
  # which is the name of a file containing configuration in yaml format
  #
  # ONE random selection from this file is actually checked.
  # If the client wishes to check ALL of the video sites, the _check_all_ 
  # method must be used.
  #
  #
  # Here is an example of the format of the configuration file.
  # ________________________________________________________________________
  # 3hk.proxy.novarra.com:
  #   mode: normal
  #   port: 8827
  #   ua_string: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.1) Gecko/2008070208 Firefox/3.0.1
  #   headers:
  #      Cookie: Novarra-Device-ID=666;SESSIONID=6
  #      Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8  #  
  #   video_sites:
  #     - uri: http://youtube.com
  #       regex: href=\"(\S+\watch\?v=\w+)\"
  #     - uri: http://hk.video.yahoo.com
  #       regex: href=\"(\S+\?id=\d+)\"
  # ________________________________________________________________________
  #
  def start(config_file)
    #Do the first check
    do_random_check(config_file)                

    #If something went wrong perform a sanity check so that we might have a better
    #idea of what is really going on...
    first_exit_code = @exit_code
    first_msg = @exit_msg
    if (first_exit_code != 0)
      #do another check
      do_random_check(config_file)
      if (@exit_code != 0)
        @exit_msg = "Double Failure 1." + first_msg + " 2." + @exit_msg
      else                  
        @exit_code =  1 #JUST A WARNING
        @exit_msg = "Single Failure " + first_msg
      end                     
    end
  end #start


  def do_random_check(config_file)
    begin
      url = ""
      #First get everything the user passed in.
      config = get_config(config_file)

      #Get a random aca from the config
      aca = config.keys[rand(config.keys.size)]

      #Get the configuration for that aca
      aca_config = config[aca]
      mode = aca_config['mode']
      port = aca_config['port']
      ua_string = aca_config['ua_string']
      headers = aca_config['headers']
      video_sites = aca_config['video_sites']
      
      #Get a random uri/regex from that aca's configuration
      url_regex = video_sites[rand(video_sites.size)]
      url = url_regex['uri']      
      video_link_regex = url_regex['regex']      

      #Perform the check on that random video site for that random aca
      doit(aca,port,headers,ua_string,mode,url,video_link_regex)

    rescue Exception => e
      warning("Config Exception " + e.to_s + trace + " url=" + url)
    end
  end
  def get_config(config_file)
    config = open(config_file) {|f| YAML.load(f)}
  end

  #
  # only for unit testing - Tests the WHOLE configuration file of video links
  # sets @exit_code to 0 if everything is OK
  #
  def check_all(config_file)
    config = get_config(config_file)
    ok = true
    error_msg = ""
    config.keys.each do |aca|
      c = config[aca]
      c['video_sites'].each do |video_site|
        doit(aca,c['port'],c['headers'],c['ua_string'],c['mode'],video_site['uri'],video_site['regex'])
        puts @exit_msg + " " + video_site['uri']
        ok = ok & (@exit_code == 0)
        error_msg = error_msg + @exit_msg unless (@exit_code == 0)
      end
    end
    @exit_code = (ok) ? 0 : 1
    @exit_msg = (ok) ? "ALL OK!" : error_msg
  end


  #
  # Actually perform a video check given all the parameters.
  #
  def doit(aca,port,headers,ua_string,mode,url,video_link_regex)
    begin
      #Bail out if called did not provide a regex for checking video content
      error("nil video_link_regex") unless (video_link_regex)
      return unless (video_link_regex)

      #Create a client to talk to this ACA
      aca_client = AcaClient.new(aca,port,headers,ua_string,mode)

      #Load the URL through the ACA.
      resp = aca_client.load(url)
      if (resp.http_status_code == 200)
        #If the content is good, clean it up and extract any base_href we find
        content = remove_newlines(resp.http_content)
        base_href = resp.base_href #get_base_url(url,content)

        #Apply the regex to find the video links, bomb out if none found.
        matches = get_matches(content,video_link_regex)
        error("no matches for #{video_link_regex} in content:#{content}") unless (matches && matches.size > 0)
        return unless (matches && matches.size > 0)

        #Construct an absolute URL out of the video link we found with the regex
        #Note: for Brew this is a p pointer which we do not resolve.
        first_match = matches[0]

        #Load that absolute URL and make sure we find an rtsp link
        resp = aca_client.load_relative(resp,first_match)
        if (resp.http_status_code == 200)
          content = remove_newlines(resp.http_content)
          if ( ((!aca_client.is_brew?) && (content =~ /href=\"rtsp:\/\/\S+\.3gp/)) ||
          ((aca_client.is_brew?) && (content =~ /src=\"rtsp:\/\/\S+\.3gp/)) )
            success("OK: " + url)
          else
            content = content.split(/</).join("\n<")
            error("Could not find rtsp content from url #{url} ")#: #{content}")
          end
        else
          error("HTTP " + resp.http_status_code.to_s + " url=" + url)
        end
      else
        error("HTTP " + resp.http_status_code.to_s + " url=" + url)
      end
    rescue Timeout::Error
      warning("Timeout Error")
    rescue Exception => e
      trace = (e.backtrace) ? e.backtrace.join("\n") : "(no trace)"
      warning("Exception " + e.to_s + trace + " url=" + url)
    end
  end

  #
  # Returns an array for all the matches on string s for a given regex.
  # NOTE: regexp_string is expected to contain one and only one grouping
  # e.g. href=\"(\S+)\"
  #
  def get_matches(s,regexp_string)
    return nil unless (s != nil && regexp_string != nil)
    r = Regexp.new(regexp_string)
    matches = s.scan(r)
    return matches[0]
  end

#  def get_base_url(absolute_url,content)
#    if (content =~ /<base href="(\S+)"/)
#       absolute_url = $1
#    end
#    return absolute_url
#  end

  def remove_newlines(content)
     return nil if not (content)
     return content.gsub(/[\r\n]+/,'')
  end

end
